/**
 * Elite Electronics - Shopping Cart Component
 * Design Philosophy: Modern Premium E-commerce
 * Displays cart items and checkout button
 */

import { Product } from '@/lib/products';
import { Button } from '@/components/ui/button';
import { X, Trash2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface CartItem extends Product {
  quantity: number;
}

interface ShoppingCartProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onRemoveItem: (productId: string) => void;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onCheckout: () => void;
}

export function ShoppingCart({
  isOpen,
  onClose,
  items,
  onRemoveItem,
  onUpdateQuantity,
  onCheckout,
}: ShoppingCartProps) {
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>سلة التسوق ({itemCount})</DialogTitle>
        </DialogHeader>

        {items.length === 0 ? (
          <div className="py-8 text-center">
            <p className="text-muted-foreground mb-4">سلتك فارغة</p>
            <Button onClick={onClose} variant="outline" className="w-full">
              متابعة التسوق
            </Button>
          </div>
        ) : (
          <>
            {/* Cart Items */}
            <div className="max-h-96 overflow-y-auto space-y-4 py-4">
              {items.map((item) => (
                <div key={item.id} className="flex gap-3 pb-4 border-b border-border">
                  {/* Product Image */}
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-20 h-20 object-cover rounded-lg"
                  />

                  {/* Product Info */}
                  <div className="flex-1">
                    <h4 className="font-semibold text-sm line-clamp-2">{item.name}</h4>
                    <p className="text-accent font-bold mt-1">${item.price}</p>

                    {/* Quantity Controls */}
                    <div className="flex items-center gap-2 mt-2">
                      <button
                        onClick={() =>
                          onUpdateQuantity(item.id, Math.max(1, item.quantity - 1))
                        }
                        className="px-2 py-1 border border-border rounded hover:bg-secondary transition-colors"
                      >
                        -
                      </button>
                      <span className="w-8 text-center">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                        className="px-2 py-1 border border-border rounded hover:bg-secondary transition-colors"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  {/* Remove Button */}
                  <button
                    onClick={() => onRemoveItem(item.id)}
                    className="text-destructive hover:bg-destructive/10 p-2 rounded transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            {/* Total and Checkout */}
            <div className="border-t border-border pt-4 space-y-4">
              <div className="flex justify-between items-center">
                <span className="font-semibold">المجموع:</span>
                <span className="text-2xl font-bold text-primary">${total.toFixed(2)}</span>
              </div>

              <Button
                onClick={onCheckout}
                className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
              >
                متابعة الدفع
              </Button>

              <Button
                onClick={onClose}
                variant="outline"
                className="w-full"
              >
                متابعة التسوق
              </Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
