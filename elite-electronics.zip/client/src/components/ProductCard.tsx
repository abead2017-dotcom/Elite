/**
 * Elite Electronics - Product Card Component
 * Design Philosophy: Modern Premium E-commerce
 * Displays individual product with image, specs, and add to cart button
 */

import { Product } from '@/lib/products';
import { Button } from '@/components/ui/button';
import { ShoppingCart, Check } from 'lucide-react';
import { useState } from 'react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const [isAdded, setIsAdded] = useState(false);

  const handleAddToCart = () => {
    onAddToCart(product);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <div className="product-card group">
      {/* Image Container */}
      <div className="relative overflow-hidden bg-gray-100 h-64">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
        />
        
        {/* Discount Badge */}
        {discount > 0 && (
          <div className="absolute top-3 right-3 bg-accent text-accent-foreground px-3 py-1 rounded-full text-sm font-semibold">
            -{discount}%
          </div>
        )}
        
        {/* Stock Status */}
        {!product.inStock && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <span className="text-white text-lg font-semibold">غير متوفر</span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4 flex flex-col gap-3">
        {/* Product Name */}
        <h3 className="text-lg font-semibold text-foreground line-clamp-2">
          {product.name}
        </h3>

        {/* Description */}
        <p className="text-sm text-muted-foreground line-clamp-2">
          {product.description}
        </p>

        {/* Specs */}
        <div className="flex flex-col gap-1">
          {product.specs.slice(0, 2).map((spec, idx) => (
            <p key={idx} className="text-xs text-muted-foreground">
              • {spec}
            </p>
          ))}
        </div>

        {/* Price */}
        <div className="flex items-center gap-2 py-2">
          <span className="text-2xl font-bold text-primary">
            ${product.price}
          </span>
          {product.originalPrice && (
            <span className="text-sm text-muted-foreground line-through">
              ${product.originalPrice}
            </span>
          )}
        </div>

        {/* Add to Cart Button */}
        <Button
          onClick={handleAddToCart}
          disabled={!product.inStock}
          className={`w-full transition-all duration-300 ${
            isAdded
              ? 'bg-green-500 hover:bg-green-500'
              : 'bg-accent hover:bg-accent/90'
          }`}
        >
          {isAdded ? (
            <>
              <Check className="w-4 h-4 mr-2" />
              تمت الإضافة
            </>
          ) : (
            <>
              <ShoppingCart className="w-4 h-4 mr-2" />
              أضف إلى السلة
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
