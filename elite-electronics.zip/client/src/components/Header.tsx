/**
 * Elite Electronics - Header Component
 * Design Philosophy: Modern Premium E-commerce
 * Navigation bar with logo, menu, and shopping cart
 */

import { ShoppingCart, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

interface HeaderProps {
  cartCount: number;
  onCartClick: () => void;
}

export function Header({ cartCount, onCartClick }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-border shadow-sm">
      <div className="container flex items-center justify-between h-16">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-lg">E</span>
          </div>
          <span className="font-bold text-xl text-primary hidden sm:inline">Elite</span>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <a href="#smartphones" className="text-foreground hover:text-accent transition-colors">
            الهواتف الذكية
          </a>
          <a href="#tablets" className="text-foreground hover:text-accent transition-colors">
            الأجهزة اللوحية
          </a>
          <a href="#laptops" className="text-foreground hover:text-accent transition-colors">
            الحواسيب المحمولة
          </a>
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-4">
          {/* Shopping Cart */}
          <button
            onClick={onCartClick}
            className="relative p-2 hover:bg-secondary rounded-lg transition-colors"
          >
            <ShoppingCart className="w-6 h-6 text-primary" />
            {cartCount > 0 && (
              <span className="absolute top-0 right-0 w-5 h-5 bg-accent text-white text-xs rounded-full flex items-center justify-center font-bold">
                {cartCount}
              </span>
            )}
          </button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 hover:bg-secondary rounded-lg transition-colors"
          >
            {isMenuOpen ? (
              <X className="w-6 h-6 text-primary" />
            ) : (
              <Menu className="w-6 h-6 text-primary" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <nav className="md:hidden border-t border-border bg-secondary">
          <div className="container py-4 flex flex-col gap-4">
            <a
              href="#smartphones"
              className="text-foreground hover:text-accent transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              الهواتف الذكية
            </a>
            <a
              href="#tablets"
              className="text-foreground hover:text-accent transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              الأجهزة اللوحية
            </a>
            <a
              href="#laptops"
              className="text-foreground hover:text-accent transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              الحواسيب المحمولة
            </a>
          </div>
        </nav>
      )}
    </header>
  );
}
