/**
 * Elite Electronics - Checkout Page
 * Design Philosophy: Modern Premium E-commerce
 * Demo payment page with payment method selection
 */

import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Check, CreditCard, Wallet } from 'lucide-react';
import { toast } from 'sonner';

interface CheckoutState {
  items: any[];
  total: number;
}

export default function Checkout() {
  const [, setLocation] = useLocation();
  const [selectedPayment, setSelectedPayment] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [orderNumber, setOrderNumber] = useState<string>('');

  // Get cart data from session storage or redirect
  const cartData = sessionStorage.getItem('elite_cart');
  const cartItems = cartData ? JSON.parse(cartData) : [];
  const total = cartItems.reduce((sum: number, item: any) => sum + item.price * item.quantity, 0);

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-4">سلتك فارغة</h1>
          <Button onClick={() => setLocation('/')} className="bg-accent">
            العودة للتسوق
          </Button>
        </div>
      </div>
    );
  }

  const handlePayment = async () => {
    if (!selectedPayment) {
      toast.error('يرجى اختيار طريقة دفع');
      return;
    }

    setIsProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      const order = `ELT-${Date.now()}`;
      setOrderNumber(order);
      setShowSuccess(true);
      sessionStorage.removeItem('elite_cart');
      setIsProcessing(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="container max-w-4xl">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-primary mb-2">إتمام الطلب</h1>
          <p className="text-muted-foreground">اختر طريقة الدفع المفضلة لديك</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Order Summary */}
          <div className="md:col-span-1">
            <Card className="p-6 sticky top-20">
              <h2 className="text-xl font-bold mb-6 text-primary">ملخص الطلب</h2>

              {/* Items */}
              <div className="space-y-4 mb-6 pb-6 border-b border-border">
                {cartItems.map((item: any) => (
                  <div key={item.id} className="flex justify-between items-start gap-4">
                    <div>
                      <p className="font-semibold text-sm line-clamp-2">{item.name}</p>
                      <p className="text-xs text-muted-foreground">الكمية: {item.quantity}</p>
                    </div>
                    <p className="font-bold text-accent">
                      ${(item.price * item.quantity).toFixed(2)}
                    </p>
                  </div>
                ))}
              </div>

              {/* Totals */}
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">المجموع الفرعي:</span>
                  <span>${total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">الشحن:</span>
                  <span className="text-accent font-semibold">مجاني</span>
                </div>
                <div className="flex justify-between pt-3 border-t border-border">
                  <span className="font-bold">الإجمالي:</span>
                  <span className="text-2xl font-bold text-primary">
                    ${total.toFixed(2)}
                  </span>
                </div>
              </div>
            </Card>
          </div>

          {/* Payment Methods */}
          <div className="md:col-span-2 space-y-6">
            {/* Bank Transfer */}
            <Card
              onClick={() => setSelectedPayment('bank')}
              className={`p-6 cursor-pointer transition-all duration-300 border-2 ${
                selectedPayment === 'bank'
                  ? 'border-accent bg-accent/5'
                  : 'border-border hover:border-accent'
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <CreditCard className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-primary">تحويل بنكي</h3>
                    <p className="text-sm text-muted-foreground">تحويل آمن من حسابك البنكي</p>
                  </div>
                </div>
                {selectedPayment === 'bank' && (
                  <div className="w-6 h-6 bg-accent rounded-full flex items-center justify-center">
                    <Check className="w-4 h-4 text-white" />
                  </div>
                )}
              </div>

              {selectedPayment === 'bank' && (
                <div className="bg-secondary p-4 rounded-lg space-y-3 text-sm">
                  <p className="font-semibold text-foreground">تفاصيل التحويل:</p>
                  <div className="space-y-2 text-muted-foreground">
                    <p><span className="font-semibold text-foreground">رقم الحساب:</span> 1234567890</p>
                    <p><span className="font-semibold text-foreground">اسم البنك:</span> البنك الأهلي</p>
                    <p><span className="font-semibold text-foreground">رمز IBAN:</span> SA1234567890123456789</p>
                    <p><span className="font-semibold text-foreground">المبلغ:</span> ${total.toFixed(2)}</p>
                  </div>
                </div>
              )}
            </Card>

            {/* My Kashi */}
            <Card
              onClick={() => setSelectedPayment('mykashi')}
              className={`p-6 cursor-pointer transition-all duration-300 border-2 ${
                selectedPayment === 'mykashi'
                  ? 'border-accent bg-accent/5'
                  : 'border-border hover:border-accent'
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                    <Wallet className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-primary">ماي كاشي</h3>
                    <p className="text-sm text-muted-foreground">محفظة رقمية آمنة وسريعة</p>
                  </div>
                </div>
                {selectedPayment === 'mykashi' && (
                  <div className="w-6 h-6 bg-accent rounded-full flex items-center justify-center">
                    <Check className="w-4 h-4 text-white" />
                  </div>
                )}
              </div>

              {selectedPayment === 'mykashi' && (
                <div className="bg-secondary p-4 rounded-lg space-y-3 text-sm">
                  <p className="font-semibold text-foreground">معلومات الدفع:</p>
                  <div className="space-y-2 text-muted-foreground">
                    <p><span className="font-semibold text-foreground">رقم المحفظة:</span> 966501234567</p>
                    <p><span className="font-semibold text-foreground">المبلغ:</span> ${total.toFixed(2)}</p>
                    <p className="text-xs pt-2 border-t border-border">سيتم تحويلك إلى تطبيق ماي كاشي لإتمام الدفع</p>
                  </div>
                </div>
              )}
            </Card>

            {/* Demo Notice */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-900">
                <span className="font-bold">ملاحظة:</span> هذا موقع عرض توضيحي. جميع خيارات الدفع وهمية للعرض فقط.
              </p>
            </div>

            {/* Payment Button */}
            <Button
              onClick={handlePayment}
              disabled={!selectedPayment || isProcessing}
              className="w-full bg-accent text-accent-foreground py-6 text-lg hover:opacity-90 transition-opacity"
            >
              {isProcessing ? 'جاري معالجة الدفع...' : 'إتمام الدفع'}
            </Button>

            {/* Back Button */}
            <Button
              onClick={() => setLocation('/')}
              variant="outline"
              className="w-full"
            >
              العودة للتسوق
            </Button>
          </div>
        </div>
      </div>

      {/* Success Dialog */}
      <Dialog open={showSuccess} onOpenChange={setShowSuccess}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl">تم الدفع بنجاح! ✓</DialogTitle>
          </DialogHeader>

          <div className="text-center space-y-6 py-6">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <Check className="w-8 h-8 text-green-600" />
            </div>

            <div>
              <p className="text-muted-foreground mb-2">رقم الطلب:</p>
              <p className="text-2xl font-bold text-primary">{orderNumber}</p>
            </div>

            <div className="bg-secondary p-4 rounded-lg">
              <p className="text-sm text-muted-foreground mb-2">المبلغ المدفوع:</p>
              <p className="text-3xl font-bold text-accent">${total.toFixed(2)}</p>
            </div>

            <p className="text-sm text-muted-foreground">
              شكراً لك على تسوقك معنا! سيتم إرسال تفاصيل الطلب إلى بريدك الإلكتروني.
            </p>

            <Button
              onClick={() => {
                setShowSuccess(false);
                setLocation('/');
              }}
              className="w-full bg-accent text-accent-foreground hover:opacity-90 transition-opacity"
            >
              العودة للرئيسية
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
