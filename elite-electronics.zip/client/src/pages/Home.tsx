/**
 * Elite Electronics - Home Page
 * Design Philosophy: Modern Premium E-commerce
 * Landing page with hero section and product catalog
 */

import { useState, useMemo, useEffect } from 'react';
import { Header } from '@/components/Header';
import { ProductCard } from '@/components/ProductCard';
import { ShoppingCart as ShoppingCartComponent } from '@/components/ShoppingCart';
import { products, categories, Product } from '@/lib/products';
import { Button } from '@/components/ui/button';
import { Smartphone, Tablet, Laptop } from 'lucide-react';

interface CartItem extends Product {
  quantity: number;
}

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Filter products by category
  const filteredProducts = useMemo(() => {
    if (!selectedCategory) return products;
    return products.filter((p) => p.category === selectedCategory);
  }, [selectedCategory]);

  // Handle add to cart
  const handleAddToCart = (product: Product) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  // Handle remove from cart
  const handleRemoveItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== productId));
  };

  // Handle update quantity
  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity === 0) {
      handleRemoveItem(productId);
    } else {
      setCartItems((prev) =>
        prev.map((item) =>
          item.id === productId ? { ...item, quantity } : item
        )
      );
    }
  };

  // Handle checkout
  const handleCheckout = () => {
    // Save cart items to session storage
    sessionStorage.setItem('elite_cart', JSON.stringify(cartItems));
    // Redirect to checkout page
    window.location.href = '/checkout';
  };

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <Header cartCount={cartCount} onCartClick={() => setIsCartOpen(true)} />

      {/* Hero Section */}
      <section className="hero-section relative bg-gradient-to-br from-primary via-primary/80 to-accent/20 py-16 md:py-24 overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-accent rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary rounded-full blur-3xl"></div>
        </div>

        <div className="container relative z-10">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            {/* Hero Text */}
            <div className="text-white">
              <h1 className="text-5xl md:text-6xl font-bold mb-4 leading-tight">
                Elite
              </h1>
              <p className="text-xl md:text-2xl mb-6 text-white/90">
                متجر النخبة للأجهزة الإلكترونية الحديثة
              </p>
              <p className="text-lg mb-8 text-white/80">
                اكتشف أحدث الهواتف الذكية والأجهزة اللوحية والحواسيب المحمولة بأفضل الأسعار
              </p>
              <Button
                onClick={() => {
                  document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="bg-accent text-accent-foreground px-8 py-3 text-lg hover:opacity-90 transition-opacity"
              >
                تسوق الآن
              </Button>
            </div>

            {/* Hero Image */}
            <div className="relative h-96 md:h-full">
              <img
                src="https://private-us-east-1.manuscdn.com/sessionFile/EZTPLhDJUl5zGNcclg5jdP/sandbox/o6ANMCbod9J5MAeSqPUlhG-img-1_1771702633000_na1fn_aGVyby1kZXZpY2Vz.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvRVpUUExoREpVbDV6R05jY2xnNWpkUC9zYW5kYm94L282QU5NQ2JvZDlKNU1BZVNxUFVsaEctaW1nLTFfMTc3MTcwMjYzMzAwMF9uYTFmbl9hR1Z5Ynkxa1pYWnBZMlZ6LnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=vgDOMHLBJBwkHUYX0l6FfWvPxw1R3CVbM6fiDeppDoHZR4uki3hOo5Dxl7Vkbx5Y65sg6XKYtxl6hz~sErxa66xyJuVOqBvuQFn1pQDBnavfFYwBAJxtUTaUZaKInjgJP8rIEBpYeVLVS1PykmJpswVFoNQ4BVxcnlacz1Wk0fGZBRMUaE6lxgW3C-ha5aoGTNvB7myHHNIQX3zYdMiaFspuI1iRnG0KQZdrAhwWGzHA~lxAHhk80VY08Jc5UAlSI17NQZbEhjmkp-BJMia09-OGBzrvs3qLYxB9zQAswEArJtqMlO-7NFdN6JkCL-mAwgZEhO~ZBdlrzYjbI1L0Bg__"
                alt="Elite Devices"
                className="w-full h-full object-contain"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Category Filter */}
      <section className="bg-white border-b border-border py-8">
        <div className="container">
          <h2 className="text-2xl font-bold mb-6 text-primary">التصنيفات</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`p-4 rounded-lg border-2 transition-all duration-300 ${
                selectedCategory === null
                  ? 'border-accent bg-accent/10'
                  : 'border-border hover:border-accent'
              }`}
            >
              <span className="font-semibold">جميع المنتجات</span>
            </button>
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`p-4 rounded-lg border-2 transition-all duration-300 flex items-center gap-3 ${
                  selectedCategory === category.id
                    ? 'border-accent bg-accent/10'
                    : 'border-border hover:border-accent'
                }`}
              >
                {category.id === 'smartphones' && <Smartphone className="w-5 h-5" />}
                {category.id === 'tablets' && <Tablet className="w-5 h-5" />}
                {category.id === 'laptops' && <Laptop className="w-5 h-5" />}
                <span className="font-semibold">{category.name}</span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section id="products" className="py-16">
        <div className="container">
          <h2 className="text-3xl font-bold mb-12 text-primary">
            {selectedCategory
              ? categories.find((c) => c.id === selectedCategory)?.name
              : 'جميع المنتجات'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-white py-12">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            {/* About */}
            <div>
              <h3 className="text-xl font-bold mb-4">عن Elite</h3>
              <p className="text-white/80">
                متجر النخبة متخصص في بيع أحدث الأجهزة الإلكترونية بأفضل الأسعار والجودة العالية.
              </p>
            </div>

            {/* Links */}
            <div>
              <h3 className="text-xl font-bold mb-4">الروابط السريعة</h3>
              <ul className="space-y-2 text-white/80">
                <li><a href="#" className="hover:text-accent transition-colors">الهواتف الذكية</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">الأجهزة اللوحية</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">الحواسيب المحمولة</a></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h3 className="text-xl font-bold mb-4">تواصل معنا</h3>
              <p className="text-white/80">
                البريد الإلكتروني: info@elite.com<br />
                الهاتف: +966 1234 5678<br />
                الموقع: الرياض، المملكة العربية السعودية
              </p>
            </div>
          </div>

          <div className="border-t border-white/20 pt-8 text-center text-white/60">
            <p>&copy; 2024 Elite Electronics. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>

      {/* Shopping Cart Dialog */}
      <ShoppingCartComponent
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onRemoveItem={handleRemoveItem}
        onUpdateQuantity={handleUpdateQuantity}
        onCheckout={handleCheckout}
      />
    </div>
  );
}
