/**
 * Elite Electronics - Product Catalog
 * Design Philosophy: Modern Premium E-commerce
 * This file contains product data for the Elite store
 */

export interface Product {
  id: string;
  name: string;
  category: 'smartphones' | 'tablets' | 'laptops';
  price: number;
  originalPrice?: number;
  image: string;
  description: string;
  specs: string[];
  inStock: boolean;
}

export const products: Product[] = [
  // Smartphones
  {
    id: 'phone-1',
    name: 'Elite Pro Max 15',
    category: 'smartphones',
    price: 1299,
    originalPrice: 1499,
    image: 'https://private-us-east-1.manuscdn.com/sessionFile/EZTPLhDJUl5zGNcclg5jdP/sandbox/o6ANMCbod9J5MAeSqPUlhG-img-2_1771702631000_na1fn_c21hcnRwaG9uZS1zaG93Y2FzZQ.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvRVpUUExoREpVbDV6R05jY2xnNWpkUC9zYW5kYm94L282QU5NQ2JvZDlKNU1BZVNxUFVsaEctaW1nLTJfMTc3MTcwMjYzMTAwMF9uYTFmbl9jMjFoY25Sd2FHOXVaUzF6YUc5M1kyRnpaUS5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=e9K8pwGwBSxvwnbWKrlrWFkbPQa01jDVSpryPe-v6RqyRQWnNTJa-w2mBuEg40ik6WWK8s-tZgDIF4TcuLO-2~Ju9eJIhoLb3d~43Q8ilmB1~Kj5YkCcp1bMMSLmSt6hivdjVkI88YHhmTIBeRxtMI46mGysN9EQ18rpb5eKgtYuc5FiihaF-sBV0O4JscnUf9y4cPak-3HLbY8Tk-I1nlD~npAoPL7vQPhcjC8od9Mj4zTfyJppznJ1AsAnzoqljaKO2DIFH2A6QOUzm4NwGeVXb3aMnOjFdkIG6UjTbvec-~fMLVGVXuf-LDA9-m7n-jX~6-1RKXtxuGQD58cHrA__',
    description: 'أحدث هاتف ذكي بتقنية متقدمة وأداء استثنائي',
    specs: ['شاشة AMOLED 6.7 بوصة', 'معالج A18 Pro', 'كاميرا 48MP', 'بطارية 4500mAh'],
    inStock: true,
  },
  {
    id: 'phone-2',
    name: 'Elite Pro 15',
    category: 'smartphones',
    price: 999,
    image: 'https://private-us-east-1.manuscdn.com/sessionFile/EZTPLhDJUl5zGNcclg5jdP/sandbox/o6ANMCbod9J5MAeSqPUlhG-img-2_1771702631000_na1fn_c21hcnRwaG9uZS1zaG93Y2FzZQ.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvRVpUUExoREpVbDV6R05jY2xnNWpkUC9zYW5kYm94L282QU5NQ2JvZDlKNU1BZVNxUFVsaEctaW1nLTJfMTc3MTcwMjYzMTAwMF9uYTFmbl9jMjFoY25Sd2FHOXVaUzF6YUc5M1kyRnpaUS5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=e9K8pwGwBSxvwnbWKrlrWFkbPQa01jDVSpryPe-v6RqyRQWnNTJa-w2mBuEg40ik6WWK8s-tZgDIF4TcuLO-2~Ju9eJIhoLb3d~43Q8ilmB1~Kj5YkCcp1bMMSLmSt6hivdjVkI88YHhmTIBeRxtMI46mGysN9EQ18rpb5eKgtYuc5FiihaF-sBV0O4JscnUf9y4cPak-3HLbY8Tk-I1nlD~npAoPL7vQPhcjC8od9Mj4zTfyJppznJ1AsAnzoqljaKO2DIFH2A6QOUzm4NwGeVXb3aMnOjFdkIG6UjTbvec-~fMLVGVXuf-LDA9-m7n-jX~6-1RKXtxuGQD58cHrA__',
    description: 'أداء عالي وتصميم أنيق',
    specs: ['شاشة OLED 6.1 بوصة', 'معالج A17 Pro', 'كاميرا 48MP', 'بطارية 3500mAh'],
    inStock: true,
  },
  {
    id: 'phone-3',
    name: 'Elite Plus',
    category: 'smartphones',
    price: 799,
    image: 'https://private-us-east-1.manuscdn.com/sessionFile/EZTPLhDJUl5zGNcclg5jdP/sandbox/o6ANMCbod9J5MAeSqPUlhG-img-2_1771702631000_na1fn_c21hcnRwaG9uZS1zaG93Y2FzZQ.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvRVpUUExoREpVbDV6R05jY2xnNWpkUC9zYW5kYm94L282QU5NQ2JvZDlKNU1BZVNxUFVsaEctaW1nLTJfMTc3MTcwMjYzMTAwMF9uYTFmbl9jMjFoY25Sd2FHOXVaUzF6YUc5M1kyRnpaUS5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=e9K8pwGwBSxvwnbWKrlrWFkbPQa01jDVSpryPe-v6RqyRQWnNTJa-w2mBuEg40ik6WWK8s-tZgDIF4TcuLO-2~Ju9eJIhoLb3d~43Q8ilmB1~Kj5YkCcp1bMMSLmSt6hivdjVkI88YHhmTIBeRxtMI46mGysN9EQ18rpb5eKgtYuc5FiihaF-sBV0O4JscnUf9y4cPak-3HLbY8Tk-I1nlD~npAoPL7vQPhcjC8od9Mj4zTfyJppznJ1AsAnzoqljaKO2DIFH2A6QOUzm4NwGeVXb3aMnOjFdkIG6UjTbvec-~fMLVGVXuf-LDA9-m7n-jX~6-1RKXtxuGQD58cHrA__',
    description: 'قيمة ممتازة بسعر معقول',
    specs: ['شاشة LCD 6.0 بوصة', 'معالج A16', 'كاميرا 40MP', 'بطارية 3200mAh'],
    inStock: true,
  },

  // Tablets
  {
    id: 'tablet-1',
    name: 'Elite Pad Pro 12.9',
    category: 'tablets',
    price: 1199,
    originalPrice: 1399,
    image: 'https://private-us-east-1.manuscdn.com/sessionFile/EZTPLhDJUl5zGNcclg5jdP/sandbox/o6ANMCbod9J5MAeSqPUlhG-img-4_1771702630000_na1fn_dGFibGV0LXNob3djYXNl.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jvbSAvc2Vzc2lvbkZpbGUvRVpUUExoREpVbDV6R05jY2xnNWpkUC9zYW5kYm94L282QU5NQ2JvZDlKNU1BZVNxUFVsaEctaW1nLTRfMTc3MTcwMjYzMDAwMF9uYTFmbl9kR0ZpYkdWMExYTm9iM2RqWVhObC5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=MtZ41bnAoQzeybf-jjYx9LYYEF5aZBrCXN3bAAFuL7BSVs9BBSc7FXSffS9vjkuNbh1G0P8hREjTL8DF861KeAj3132dyWUS5DH6g3ADtXL6xqUIk0mgKE8xDMPm50oFi3tf8q0jZV5jiaasQziXstXaturnjezTvPjhaCY4yHPVML2iwXSSC0y0M6g03Df2BGljpRRUZXy~lsEERIv01FUSEOugzIzFce4Qas5MCH~UbkMwQ4kowecB-zTR6~Qo39t7ggUGW~0noJIwSeFHC4zYyOx37wH5YdK0baLUzraAXYVNQBSfZGdBkrRto1KisLTSbqzPIh2CtJuzaKsOQQ__',
    description: 'جهاز لوحي قوي للعمل والإبداع',
    specs: ['شاشة Liquid Retina 12.9 بوصة', 'معالج M2', 'كاميرا 12MP', 'بطارية 10000mAh'],
    inStock: true,
  },
  {
    id: 'tablet-2',
    name: 'Elite Pad Air 10.9',
    category: 'tablets',
    price: 799,
    image: 'https://private-us-east-1.manuscdn.com/sessionFile/EZTPLhDJUl5zGNcclg5jdP/sandbox/o6ANMCbod9J5MAeSqPUlhG-img-4_1771702630000_na1fn_dGFibGV0LXNob3djYXNl.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvRVpUUExoREpVbDV6R05jY2xnNWpkUC9zYW5kYm94L282QU5NQ2JvZDlKNU1BZVNxUFVsaEctaW1nLTRfMTc3MTcwMjYzMDAwMF9uYTFmbl9kR0ZpYkdWMExYTm9iM2RqWVhObC5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=MtZ41bnAoQzeybf-jjYx9LYYEF5aZBrCXN3bAAFuL7BSVs9BBSc7FXSffS9vjkuNbh1G0P8hREjTL8DF861KeAj3132dyWUS5DH6g3ADtXL6xqUIk0mgKE8xDMPm50oFi3tf8q0jZV5jiaasQziXstXaturnjezTvPjhaCY4yHPVML2iwXSSC0y0M6g03Df2BGljpRRUZXy~lsEERIv01FUSEOugzIzFce4Qas5MCH~UbkMwQ4kowecB-zTR6~Qo39t7ggUGW~0noJIwSeFHC4zYyOx37wH5YdK0baLUzraAXYVNQBSfZGdBkrRto1KisLTSbqzPIh2CtJuzaKsOQQ__',
    description: 'أداء متوازن وحجم مريح',
    specs: ['شاشة Liquid Retina 10.9 بوصة', 'معالج M1', 'كاميرا 10MP', 'بطارية 8000mAh'],
    inStock: true,
  },
  {
    id: 'tablet-3',
    name: 'Elite Pad Mini 8.3',
    category: 'tablets',
    price: 499,
    image: 'https://private-us-east-1.manuscdn.com/sessionFile/EZTPLhDJUl5zGNcclg5jdP/sandbox/o6ANMCbod9J5MAeSqPUlhG-img-4_1771702630000_na1fn_dGFibGV0LXNob3djYXNl.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvRVpUUExoREpVbDV6R05jY2xnNWpkUC9zYW5kYm94L282QU5NQ2JvZDlKNU1BZVNxUFVsaEctaW1nLTRfMTc3MTcwMjYzMDAwMF9uYTFmbl9kR0ZpYkdWMExYTm9iM2RqWVhObC5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=MtZ41bnAoQzeybf-jjYx9LYYEF5aZBrCXN3bAAFuL7BSVs9BBSc7FXSffS9vjkuNbh1G0P8hREjTL8DF861KeAj3132dyWUS5DH6g3ADtXL6xqUIk0mgKE8xDMPm50oFi3tf8q0jZV5jiaasQziXstXaturnjezTvPjhaCY4yHPVML2iwXSSC0y0M6g03Df2BGljpRRUZXy~lsEERIv01FUSEOugzIzFce4Qas5MCH~UbkMwQ4kowecB-zTR6~Qo39t7ggUGW~0noJIwSeFHC4zYyOx37wH5YdK0baLUzraAXYVNQBSfZGdBkrRto1KisLTSbqzPIh2CtJuzaKsOQQ__',
    description: 'محمول وخفيف الوزن',
    specs: ['شاشة Liquid Retina 8.3 بوصة', 'معالج A15', 'كاميرا 8MP', 'بطارية 5000mAh'],
    inStock: false,
  },

  // Laptops
  {
    id: 'laptop-1',
    name: 'Elite Book Pro 16',
    category: 'laptops',
    price: 2499,
    originalPrice: 2799,
    image: 'https://private-us-east-1.manuscdn.com/sessionFile/EZTPLhDJUl5zGNcclg5jdP/sandbox/o6ANMCbod9J5MAeSqPUlhG-img-3_1771702629000_na1fn_bGFwdG9wLXNob3djYXNl.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvRVpUUExoREpVbDV6R05jY2xnNWpkUC9zYW5kYm94L282QU5NQ2JvZDlKNU1BZVNxUFVsaEctaW1nLTNfMTc3MTcwMjYyOTAwMF9uYTFmbl9iR0Z3ZEc5d0xYTm9iM2RqWVhObC5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=tZ-zeRQc7-6CAbxcOjm4pfJVT94fr98ygTjEocrR9wdBxfjCaK1mEqpa0gTrGK~ygk-bC8Vvv8QR0pfco0-pB4Q5Pn4DhRNkjIbCTtNmAtkaVzEBhZL4VzzDunuFmmTY7Pab7vMReINPQeqzCxv8GNTM4SMTtTpppXB8P4jsooVdMNDRt3c8I4I5NeKyJXCYvlYgBEPD1V6O9UlvcK8yThGDkGia4F2tI7a59XDYs2kwejFUeWF-4uxmIu3xuxbrCDg-dOfVRhsBjF3BFixEnf052VfQP6~8P8S8n9FFLVVq1bJuWf~7OxkaSJfegE-Y9tgFbFV3~InprZb3FEhRoA__',
    description: 'حاسوب محمول احترافي عالي الأداء',
    specs: ['شاشة 16 بوصة 4K', 'معالج Intel i9', 'ذاكرة 32GB RAM', 'SSD 1TB'],
    inStock: true,
  },
  {
    id: 'laptop-2',
    name: 'Elite Book Air 14',
    category: 'laptops',
    price: 1599,
    image: 'https://private-us-east-1.manuscdn.com/sessionFile/EZTPLhDJUl5zGNcclg5jdP/sandbox/o6ANMCbod9J5MAeSqPUlhG-img-3_1771702629000_na1fn_bGFwdG9wLXNob3djYXNl.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvRVpUUExoREpVbDV6R05jY2xnNWpkUC9zYW5kYm94L282QU5NQ2JvZDlKNU1BZVNxUFVsaEctaW1nLTNfMTc3MTcwMjYyOTAwMF9uYTFmbl9iR0Z3ZEc5d0xYTm9iM2RqWVhObC5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=tZ-zeRQc7-6CAbxcOjm4pfJVT94fr98ygTjEocrR9wdBxfjCaK1mEqpa0gTrGK~ygk-bC8Vvv8QR0pfco0-pB4Q5Pn4DhRNkjIbCTtNmAtkaVzEBhZL4VzzDunuFmmTY7Pab7vMReINPQeqzCxv8GNTM4SMTtTpppXB8P4jsooVdMNDRt3c8I4I5NeKyJXCYvlYgBEPD1V6O9UlvcK8yThGDkGia4F2tI7a59XDYs2kwejFUeWF-4uxmIu3xuxbrCDg-dOfVRhsBjF3BFixEnf052VfQP6~8P8S8n9FFLVVq1bJuWf~7OxkaSJfegE-Y9tgFbFV3~InprZb3FEhRoA__',
    description: 'خفيف الوزن وفعال للعمل اليومي',
    specs: ['شاشة 14 بوصة FHD', 'معالج Intel i7', 'ذاكرة 16GB RAM', 'SSD 512GB'],
    inStock: true,
  },
  {
    id: 'laptop-3',
    name: 'Elite Book Standard 15',
    category: 'laptops',
    price: 999,
    image: 'https://private-us-east-1.manuscdn.com/sessionFile/EZTPLhDJUl5zGNcclg5jdP/sandbox/o6ANMCbod9J5MAeSqPUlhG-img-3_1771702629000_na1fn_bGFwdG9wLXNob3djYXNl.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvRVpUUExoREpVbDV6R05jY2xnNWpkUC9zYW5kYm94L282QU5NQ2JvZDlKNU1BZVNxUFVsaEctaW1nLTNfMTc3MTcwMjYyOTAwMF9uYTFmbl9iR0Z3ZEc5d0xYTm9iM2RqWVhObC5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=tZ-zeRQc7-6CAbxcOjm4pfJVT94fr98ygTjEocrR9wdBxfjCaK1mEqpa0gTrGK~ygk-bC8Vvv8QR0pfco0-pB4Q5Pn4DhRNkjIbCTtNmAtkaVzEBhZL4VzzDunuFmmTY7Pab7vMReINPQeqzCxv8GNTM4SMTtTpppXB8P4jsooVdMNDRt3c8I4I5NeKyJXCYvlYgBEPD1V6O9UlvcK8yThGDkGia4F2tI7a59XDYs2kwejFUeWF-4uxmIu3xuxbrCDg-dOfVRhsBjF3BFixEnf052VfQP6~8P8S8n9FFLVVq1bJuWf~7OxkaSJfegE-Y9tgFbFV3~InprZb3FEhRoA__',
    description: 'قيمة رائعة للاستخدام العام',
    specs: ['شاشة 15 بوصة HD', 'معالج Intel i5', 'ذاكرة 8GB RAM', 'SSD 256GB'],
    inStock: true,
  },
];

export const categories = [
  { id: 'smartphones', name: 'الهواتف الذكية', icon: 'Smartphone' },
  { id: 'tablets', name: 'الأجهزة اللوحية', icon: 'Tablet' },
  { id: 'laptops', name: 'الحواسيب المحمولة', icon: 'Laptop' },
];
